# PDF Text Extractor (LWC)

A 100% client-side Lightning Web Component that extracts all text from a PDF
and displays it, using the browser's `FileReader` API and Mozilla's
**PDF.js** library. No Apex, no `ContentVersion`/`ContentDocument`, and the
PDF is never saved in Salesforce — everything happens in the browser.

## Files

- `pdfTextExtractor.js` – component logic (file validation, extraction, pagination-free full display)
- `pdfTextExtractor.html` – SLDS-based markup (drag-and-drop zone, file details, spinner, results)
- `pdfTextExtractor.css` – styling, fully responsive
- `pdfTextExtractor.js-meta.xml` – exposes the component to App, Record, Home pages and as a Tab

## One-time setup: upload PDF.js as a Static Resource

The component expects a static resource named **`pdfjs`** containing the
PDF.js distribution, structured like this inside the zip:

```
pdfjs.zip
└── pdfjs/
    └── build/
        └── pdf.min.js
```

Steps:

1. Download a PDF.js build from the official Mozilla project:
   https://mozilla.github.io/pdf.js/getting_started/#download
   (grab the "prebuilt" release, e.g. `pdfjs-dist`).
2. From the downloaded package, copy `build/pdf.min.js` into a folder named
   `pdfjs/build/pdf.min.js`.
3. Zip the top-level `pdfjs` folder so the zip contains `pdfjs/build/pdf.min.js`.
4. In Salesforce Setup → **Static Resources** → **New**, upload the zip and
   name it exactly `pdfjs` (Cache Control: Public).
5. Deploy the four component files in this folder to your org (e.g. via
   Salesforce CLI: `sf project deploy start -d force-app/main/default/lwc/pdfTextExtractor`,
   after placing the folder under your DX project's `lwc` directory).

> Note: This component runs PDF.js on the main thread
> (`GlobalWorkerOptions.workerSrc = null`) rather than loading a separate
> worker file, since Lightning Locker/LWS restricts loading additional
> scripts from a static resource as a Web Worker. This is a supported PDF.js
> fallback mode and works well for typical document sizes.

## How it works

1. **Select a file** – via drag-and-drop or the **Browse File** button.
   Only `.pdf` files are accepted; anything else shows an inline error.
2. **File details** are shown: name, size, and last modified date. If the
   file is 12 MB or larger, a warning is shown but the user can still
   proceed.
3. **Submit** reads the file with `FileReader.readAsArrayBuffer`, hands the
   buffer to `pdfjsLib.getDocument`, then loops through every page in order,
   calling `page.getTextContent()`.
4. For each page, text items are grouped by their vertical position and
   sorted left-to-right within each line, then lines are ordered top-to-
   bottom. This reconstructs headings, paragraphs, bullet lists, and
   table-like rows far more faithfully than a single flat text join, while
   still being pure client-side text extraction (no layout engine).
5. A progress bar updates as each page finishes, and a spinner overlays the
   form while processing.
6. When done, all page text is combined (in original page order, with
   `--- Page N of M ---` separators) and displayed in a scrollable,
   monospace, pre-formatted block so nothing is summarized, reformatted, or
   truncated.
7. **Clear** resets the component so another PDF can be uploaded.

## Limitations to be aware of

- PDF.js text extraction returns the text layer of a PDF; it does not run
  OCR, so scanned/image-only PDFs will yield little or no text.
- Table reconstruction is "best effort" — it's driven by the line-grouping
  heuristic (same code handles headings, paragraphs, lists, numbers, dates,
  URLs, emails, phone numbers, and special characters, since these are just
  characters within the text layer), not a full layout/table parser.
- Very large PDFs (dozens of MB) may take noticeably longer since parsing
  happens entirely in the browser's main thread.

import { LightningElement, track } from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';
import PDFJS from '@salesforce/resourceUrl/pdfjs';

const SIZE_WARNING_BYTES = 12 * 1024 * 1024; // 12 MB
const LINE_Y_TOLERANCE = 2; // px tolerance when grouping text items into the same line

export default class PdfTextExtractor extends LightningElement {

    // ---- library state ----
    pdfJsInitialized = false;
    pdfJsLoadError = false;
    pdfjsLib;

    // ---- file state ----
    @track selectedFile = null;
    fileName = '';
    fileSizeLabel = '';
    fileLastModifiedLabel = '';
    isDragOver = false;
    sizeWarningMessage = '';

    // ---- processing state ----
    @track isProcessing = false;
    @track progress = 0;
    totalPages = 0;
    pagesProcessed = 0;

    // ---- result / message state ----
    @track extractedText = '';
    @track errorMessage = '';
    @track successMessage = '';

    // =====================================================================
    // LIFECYCLE
    // =====================================================================

    renderedCallback() {
        if (this.pdfJsInitialized) {
            return;
        }
        this.pdfJsInitialized = true;

        loadScript(this, PDFJS + '/pdfjs/build/pdf.min.js')
            .then(() => {
                this.pdfjsLib = window.pdfjsLib;
                // Run PDF.js on the main thread (no separate worker file deployed
                // as a static resource), which is a supported fallback mode.
                this.pdfjsLib.GlobalWorkerOptions.workerSrc = null;
            })
            .catch((error) => {
                this.pdfJsLoadError = true;
                this.errorMessage =
                    'Unable to load the PDF processing library. Please refresh the page and try again.';
                // eslint-disable-next-line no-console
                console.error('PDF.js load error', error);
            });
    }

    // =====================================================================
    // FILE SELECTION - BROWSE BUTTON
    // =====================================================================

    handleBrowseClick() {
        this.template.querySelector('input.file-input').click();
    }

    handleFileInputChange(event) {
        const file = event.target.files && event.target.files[0];
        if (file) {
            this.processSelectedFile(file);
        }
        // reset so selecting the same file again still fires 'change'
        event.target.value = '';
    }

    // =====================================================================
    // FILE SELECTION - DRAG AND DROP
    // =====================================================================

    handleDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver = true;
    }

    handleDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver = false;
    }

    handleDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver = false;

        const files = event.dataTransfer && event.dataTransfer.files;
        if (files && files.length > 0) {
            this.processSelectedFile(files[0]);
        }
    }

    // =====================================================================
    // FILE VALIDATION
    // =====================================================================

    processSelectedFile(file) {
        this.clearMessages();

        const isPdfByType = file.type === 'application/pdf';
        const isPdfByExtension = file.name && file.name.toLowerCase().endsWith('.pdf');

        if (!isPdfByType && !isPdfByExtension) {
            this.errorMessage = `"${file.name}" is not a PDF file. Please select a file with a .pdf extension.`;
            this.selectedFile = null;
            this.fileName = '';
            this.fileSizeLabel = '';
            this.fileLastModifiedLabel = '';
            return;
        }

        this.selectedFile = file;
        this.fileName = file.name;
        this.fileSizeLabel = this.formatFileSize(file.size);
        this.fileLastModifiedLabel = this.formatDate(file.lastModified);

        // reset any previous extraction results
        this.extractedText = '';
        this.totalPages = 0;
        this.pagesProcessed = 0;
        this.progress = 0;

        if (file.size >= SIZE_WARNING_BYTES) {
            this.errorMessage = '';
            this.successMessage = '';
            this.sizeWarningMessage = `This file is ${this.fileSizeLabel}, which is 12 MB or larger. Processing large PDFs in the browser may take longer. You can still continue.`;
        } else {
            this.sizeWarningMessage = '';
        }
    }

    // =====================================================================
    // SUBMIT / EXTRACTION
    // =====================================================================

    async handleSubmit() {
        this.clearMessages();

        if (!this.selectedFile) {
            this.errorMessage = 'Please select a PDF file before submitting.';
            return;
        }

        if (!this.pdfjsLib) {
            this.errorMessage = 'The PDF processing library is not ready yet. Please wait a moment and try again.';
            return;
        }

        this.isProcessing = true;
        this.progress = 0;
        this.extractedText = '';
        this.pagesProcessed = 0;

        let pdfDocument = null;

        try {
            const arrayBuffer = await this.readFileAsArrayBuffer(this.selectedFile);

            const loadingTask = this.pdfjsLib.getDocument({ data: arrayBuffer });
            pdfDocument = await loadingTask.promise;

            this.totalPages = pdfDocument.numPages;

            const pageTexts = [];

            for (let pageNumber = 1; pageNumber <= this.totalPages; pageNumber++) {
                const pageText = await this.extractPageText(pdfDocument, pageNumber);
                pageTexts.push(pageText);

                this.pagesProcessed = pageNumber;
                this.progress = Math.round((pageNumber / this.totalPages) * 100);

                // yield to the render loop so the progress bar updates smoothly
                // eslint-disable-next-line no-await-in-loop
                await this.nextFrame();
            }

            this.extractedText = pageTexts.join('\n\n');
            this.successMessage = `Successfully extracted text from ${this.totalPages} page${this.totalPages === 1 ? '' : 's'} of "${this.fileName}".`;
        } catch (error) {
            // eslint-disable-next-line no-console
            console.error('PDF extraction error', error);
            this.errorMessage = `Something went wrong while extracting text from this PDF: ${error && error.message ? error.message : error}`;
        } finally {
            this.isProcessing = false;
            if (pdfDocument) {
                try {
                    pdfDocument.destroy();
                } catch (cleanupError) {
                    // eslint-disable-next-line no-console
                    console.error('PDF cleanup error', cleanupError);
                }
            }
        }
    }

    // =====================================================================
    // CLEAR
    // =====================================================================

    handleClear() {
        this.selectedFile = null;
        this.fileName = '';
        this.fileSizeLabel = '';
        this.fileLastModifiedLabel = '';
        this.sizeWarningMessage = '';
        this.extractedText = '';
        this.totalPages = 0;
        this.pagesProcessed = 0;
        this.progress = 0;
        this.clearMessages();
    }

    clearMessages() {
        this.errorMessage = '';
        this.successMessage = '';
        this.sizeWarningMessage = '';
    }

    // =====================================================================
    // HELPERS
    // =====================================================================

    readFileAsArrayBuffer(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(reader.error || new Error('Unable to read the selected file.'));
            reader.readAsArrayBuffer(file);
        });
    }

    /**
     * Extracts text for a single page and rebuilds line breaks by grouping
     * text items that share (roughly) the same vertical position, then
     * ordering those lines top-to-bottom and each line's items left-to-right.
     * This preserves layout (paragraphs, lists, table rows) far better than
     * a single flat join of every text run on the page.
     */
    async extractPageText(pdfDocument, pageNumber) {
        let page;
        try {
            page = await pdfDocument.getPage(pageNumber);
            const textContent = await page.getTextContent();

            const lines = [];

            textContent.items.forEach((item) => {
                const str = item.str;
                // transform[5] is the y coordinate of the text item's baseline
                const y = item.transform[5];
                const x = item.transform[4];

                let line = lines.find((l) => Math.abs(l.y - y) <= LINE_Y_TOLERANCE);
                if (!line) {
                    line = { y, items: [] };
                    lines.push(line);
                }
                line.items.push({ x, str });

                // preserve explicit line-break hints from PDF.js when present
                if (item.hasEOL) {
                    line.hasEOL = true;
                }
            });

            // top of page first (higher y = higher on the page in PDF space)
            lines.sort((a, b) => b.y - a.y);

            const pageLines = lines.map((line) => {
                line.items.sort((a, b) => a.x - b.x);
                return line.items.map((i) => i.str).join(' ').replace(/\s+/g, ' ').trim();
            }).filter((lineText) => lineText.length > 0);

            page.cleanup();

            const header = `--- Page ${pageNumber} of ${this.totalPages} ---`;
            const body = pageLines.length > 0 ? pageLines.join('\n') : '[No extractable text on this page]';
            return `${header}\n${body}`;
        } catch (error) {
            // eslint-disable-next-line no-console
            console.error(`Error extracting page ${pageNumber}`, error);
            return `--- Page ${pageNumber} of ${this.totalPages} ---\n[Unable to extract text from this page]`;
        }
    }

    nextFrame() {
        return new Promise((resolve) => setTimeout(resolve, 0));
    }

    formatFileSize(bytes) {
        if (bytes < 1024) {
            return `${bytes} B`;
        }
        if (bytes < 1024 * 1024) {
            return `${(bytes / 1024).toFixed(1)} KB`;
        }
        return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }

    formatDate(timestamp) {
        if (!timestamp) {
            return '';
        }
        const date = new Date(timestamp);
        return date.toLocaleString(undefined, {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // =====================================================================
    // GETTERS FOR TEMPLATE
    // =====================================================================

    get hasSelectedFile() {
        return !!this.selectedFile;
    }

    get hasExtractedText() {
        return !!this.extractedText;
    }

    get hasError() {
        return !!this.errorMessage;
    }

    get hasSuccess() {
        return !!this.successMessage;
    }

    get hasSizeWarning() {
        return !!this.sizeWarningMessage;
    }

    get disableSubmit() {
        return !this.selectedFile || this.isProcessing;
    }

    get dropZoneClass() {
        return this.isDragOver
            ? 'drop-zone drop-zone_active'
            : 'drop-zone';
    }

    get progressLabel() {
        return `Extracting page ${this.pagesProcessed} of ${this.totalPages}\u2026 (${this.progress}%)`;
    }
}
